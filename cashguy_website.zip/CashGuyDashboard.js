import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";

export default function CashGuyDashboard() {
  const [income, setIncome] = useState(0);
  const [expense, setExpense] = useState(0);
  const [transactions, setTransactions] = useState([]);

  const addTransaction = (type) => {
    const amount = type === "income" ? income : expense;
    if (amount > 0) {
      setTransactions([...transactions, { type, amount, date: new Date().toLocaleDateString() }]);
      type === "income" ? setIncome(0) : setExpense(0);
    }
  };

  const data = transactions.map((t, index) => ({ name: t.date, amount: t.amount, type: t.type }));

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">CashGuy - ניהול תקציב</h1>
      <Card>
        <CardContent className="p-4">
          <div className="flex space-x-4">
            <Input
              type="number"
              placeholder="הכנסה"
              value={income}
              onChange={(e) => setIncome(Number(e.target.value))}
            />
            <Button onClick={() => addTransaction("income")}>הוסף הכנסה</Button>
          </div>
          <div className="flex space-x-4 mt-4">
            <Input
              type="number"
              placeholder="הוצאה"
              value={expense}
              onChange={(e) => setExpense(Number(e.target.value))}
            />
            <Button onClick={() => addTransaction("expense")}>הוסף הוצאה</Button>
          </div>
        </CardContent>
      </Card>
      <h2 className="text-xl font-bold mt-6">גרף תזרים</h2>
      <LineChart width={600} height={300} data={data} className="mt-4">
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="amount" stroke="#8884d8" />
      </LineChart>
    </div>
  );
}
